# tree-sitter-zsh

[![CI](https://github.com/konomanoasa/tree-sitter-zsh/actions/workflows/ci.yaml/badge.svg)](https://github.com/konomanoasa/tree-sitter-zsh/actions/workflows/ci.yaml)
[![crates.io](https://img.shields.io/crates/v/konomanoasa-tree-sitter-zsh)](https://crates.io/crates/konomanoasa-tree-sitter-zsh)
[![npm](https://img.shields.io/npm/v/@konomanoasa/tree-sitter-zsh)](https://www.npmjs.com/package/@konomanoasa/tree-sitter-zsh)
[![PyPI](https://img.shields.io/pypi/v/konomanoasa-tree-sitter-zsh)](https://pypi.org/project/konomanoasa-tree-sitter-zsh/)

[Tree-sitter](https://tree-sitter.github.io/tree-sitter/) grammars for
Z Shell 5.9.2.

## Installation

```sh
npm install @konomanoasa/tree-sitter-zsh
```

## Parsing Option

For zsh parsing with `EXTENDED_GLOB` enabled, use `zsh_extended_glob`.

## Parsing Policy

[Parsing Policy](PARSING_POLICY.md)

## Development

```sh
npm ci
npm test
```

## Specification

[zsh Manual, Version 5.9.2](https://zsh.sourceforge.io/Doc/Release/)

## License

[MIT](LICENSE)
